#define _XOPEN_SOURCE 700

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

#include <errno.h>
#include <pthread.h>
#include <string.h>


#define check_error(cond,userMsg)\
	do { \
		if (!(cond)) { \
			perror(userMsg);\
			exit(EXIT_FAILURE);\
		}\
	} while(0)

#define check_pthread(errNum,userMsg) \
	do {\
		int _err = (errNum);\
		if (_err > 0) { \
			errno = _err; \
			check_error(0,userMsg); \
		}\
	} while (0)
		


// ./3 link.txt
int main(int argc, char** argv) {
	
	check_error(argc == 2, "...");
	
	int fd = open(argv[1], O_RDONLY);
	check_error(fd != -1, "...");
	
	struct stat fInfo;
	check_error(fstat(fd, &fInfo) != -1, "...");
	
	if(S_ISREG(fInfo.st_mode)){
		printf("regularan ");
	}
	if(S_ISDIR(fInfo.st_mode)){
		printf("direktorijum ");
	}
	if(S_ISCHR(fInfo.st_mode)){
		printf("karakter ");
	}
	if(S_ISFIFO(fInfo.st_mode)){
		printf("pajp ");
	}
	if(S_ISLNK(fInfo.st_mode)){
		printf("link ");
	}
	if(S_ISSOCK(fInfo.st_mode)){
		printf("soket ");
	}
	if(S_ISBLK(fInfo.st_mode)){
		printf("blok ");
	}

	char* realPath = realpath(argv[1], NULL);
	check_error(realPath != NULL, "...");
	
	char *ekstenzija = NULL;
	ekstenzija = strrchr(realPath,'.');
	
	if(ekstenzija == NULL){
		printf("nema\n");
	}
	else{
		printf("%s", ekstenzija);
	}
		

	
	exit(EXIT_SUCCESS);
}
