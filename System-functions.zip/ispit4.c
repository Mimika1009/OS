#define _XOPEN_SOURCE 700

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

#include <errno.h>
#include <pthread.h>
#include <string.h>
#include <ftw.h>

#define check_error(cond,userMsg)\
	do { \
		if (!(cond)) { \
			perror(userMsg);\
			exit(EXIT_FAILURE);\
		}\
	} while(0)

#define check_pthread(errNum,userMsg) \
	do {\
		int _err = (errNum);\
		if (_err > 0) { \
			errno = _err; \
			check_error(0,userMsg); \
		}\
	} while (0)
	
	
int brojac = 0;
int p, k;
char ext[10];

	

int processFile(const char* fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf){
	
	char *ekstenzija = NULL;
	ekstenzija = strrchr(fpath + ftwbuf->base, '.');
	
	if(ekstenzija == NULL)
		return 0;
		
	
	for(int i = p; i <= k; i++){
		if(ftwbuf->level == i){		
				if(!strcmp(ekstenzija, ext)){
					brojac++;
				}	
		}							
	}
	
	return 0;
}
		

// ./4 fpath ekst p k
int main(int argc, char** argv) {
	
	check_error(argc == 5, "...");
	
	struct stat fInfo;
	check_error(stat(argv[1], &fInfo) != -1, "...");
	

	if(!S_ISDIR(fInfo.st_mode)){
		check_error(0, "nije direktorijum");
	}
	
	
	p = atoi(argv[3]);
	k = atoi(argv[4]);
	strcpy(ext, argv[2]);
	
	check_error(nftw(argv[1], processFile, 50, 0) != -1, "...");
	
	printf("%d\n", brojac);
	
	
	exit(EXIT_SUCCESS);
}


