#define _XOPEN_SOURCE 700

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

#include <errno.h>
#include <pthread.h>
#include <string.h>
#include <sys/mman.h>
#include <ctype.h>
#include <semaphore.h>

#define ARRAY_MAX (1024)

#define check_error(cond,userMsg)\
	do { \
		if (!(cond)) { \
			perror(userMsg);\
			exit(EXIT_FAILURE);\
		}\
	} while(0)

#define check_pthread(errNum,userMsg) \
	do {\
		int _err = (errNum);\
		if (_err > 0) { \
			errno = _err; \
			check_error(0,userMsg); \
		}\
	} while (0)
		
typedef struct {
	sem_t inDataReady;
	sem_t dataProcessed;
	char str[ARRAY_MAX];
} osInputData;


void *getMemoryBlock(const char* fpath, unsigned* size){
	int memFd = shm_open(fpath, O_RDWR, 0644);
	check_error(memFd != -1, "...");
	
	struct stat fInfo;
	check_error(fstat(memFd, &fInfo) != -1, "stat");
	
	*size = fInfo.st_size;
	
	void *addr = mmap(NULL, *size, PROT_READ | PROT_WRITE, MAP_SHARED, memFd, 0);
	check_error(addr != MAP_FAILED, "mmap");
	
	return addr;
}


// ./4 shm1 -lrt -pthread || -lpthread
int main(int argc, char** argv) {
	
	check_error(argc == 2, "argumenti");
	unsigned size = 0;
	
	osInputData* sharedMem = (osInputData*)getMemoryBlock(argv[1],&size);
	
	check_error(sem_wait(&(sharedMem->inDataReady)) != -1, "...");
	
	for(int i = 0; i < strlen(sharedMem->str); i++){
		sharedMem->str[i] = toupper(sharedMem->str[i]);
	}
	
	check_error(sem_post(&(sharedMem->dataProcessed)) != -1, "...");
	

	check_error(munmap(sharedMem, size) != -1, "...");
	exit(EXIT_SUCCESS);
}
